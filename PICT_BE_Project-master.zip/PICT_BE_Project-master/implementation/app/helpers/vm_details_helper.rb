module VmDetailsHelper
end
