class Vendor < ApplicationRecord
  belongs_to :vendingmachine
end
