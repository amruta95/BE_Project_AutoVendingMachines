require 'test_helper'

class VmDetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
